﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using ZadanieKolko.Model;
using UtilitiesWpf;

namespace ZadanieKolko.ViewModel
{
    class TicTacToeViewModel : ObserverVM
    {

        bool gameOver = false;
        int round;
        string[] button;

        public TicTacToeViewModel()
        {
            ResetGame();

            ClickButton = new RelayCommand<object>(
                o =>
                {
                    int cell = Convert.ToInt32(o);
                    if (gameOver == true)
                    {
                        IsClickable = new ObservableCollection<bool>(new bool[] { false, false, false, false, false, false, false, false, false });
                    }
                    if (IsClickable[cell])
                    {
                        round++;
                        Content[cell].Mark = CircleOrCross();
                        IsClickable[cell] = false;
                        button[cell] = CircleOrCross();

                        CheckWinner();
                    }
                });

            ResetGameCommand = new RelayCommand<object>(
                x =>
                {
                    ResetGame();
                },
                x =>
                {
                    return gameOver;
                });


            ResetScoreCommand = new RelayCommand<object>(
                x =>
                {
                    ResetScore();
                       
                });
              
        }


        #region ResetGameButton
        private void ResetGame()
        {
            round = 0;
            gameOver = false;
            button = new string[] { "0", "1", "2", "3", "4", "5", "6", "7", "8" };
            Content = new ObservableCollection<Field>();
            IsClickable = new ObservableCollection<bool>(new bool[] { true, true, true, true, true, true, true, true, true });

            for (int i = 0; i < 9; i++)
            {
                Content.Add(new Field() { Mark = "" });
            }
        }
        #endregion

        #region conditions
        private void checkForWin()
        {
            gameOver = true;

            if (CircleOrCross().Equals("X"))
            {
                MessageBox.Show("Player X won!");
                CrossScore++;

            }
            else
            {
                MessageBox.Show("Player O won!");
                CircleScore++;
            }
        }

      

        private string CircleOrCross()
        {
            return (round % 2 == 0) ? "O" : "X";
        }
        #endregion

        #region properties

        private ICommand clickButton;

        public ICommand ClickButton
        {
            get { return clickButton; }
            set
            {
                clickButton = value;
                OnPropertyChanged(nameof(ClickButton));
            }
        }

        private ICommand resetGameCommand;

        public ICommand ResetGameCommand
        {
            get { return resetGameCommand; }
            set
            {
                resetGameCommand = value;
                OnPropertyChanged(nameof(ResetGameCommand));
               
                
            }
        }

        private ICommand resetScoreCommand;

        public ICommand ResetScoreCommand
        {
            get { return resetScoreCommand; }
            set
            {
                resetScoreCommand = value;
                OnPropertyChanged(nameof(ResetScoreCommand));
                ResetScore();
              

            }
        }

        private ObservableCollection<Field> content;

        public ObservableCollection<Field> Content
        {
            get { return content; }
            set
            {
                content = value;
                OnPropertyChanged(nameof(Content));
            }
        }

        private ObservableCollection<bool> isClickable;

        public ObservableCollection<bool> IsClickable
        {
            get { return isClickable; }
            set
            {
                isClickable = value;
                OnPropertyChanged(nameof(IsClickable));
            }
        }

        private int _circleScore;

        public int CircleScore
        {
            get { return _circleScore; }
            set
            {
                _circleScore = value;
                OnPropertyChanged(nameof(CircleScore));
            }
        }

        private int _crossScore;

        public int CrossScore
        {
            get { return _crossScore; }
            set
            {
                _crossScore = value;
                OnPropertyChanged(nameof(CrossScore));
            }
        }

        private void CheckWinner()
        {
            if (button[0] == button[1] && button[1] == button[2])
            {
                
                checkForWin();

                return;
            }
            else if (button[3] == button[4] && button[4] == button[5])
            {
                
                checkForWin();

                return;
            }
            else if (button[6] == button[7] && button[7] == button[8])
            {
                
                checkForWin();

                return;
            }
            else if (button[0] == button[3] && button[3] == button[6])
            {
                
                checkForWin();

                return;
            }
            else if (button[1] == button[4] && button[4] == button[7])
            {
                
                checkForWin();

                return;
            }
            else if (button[2] == button[1] && button[5] == button[8])
            {
                
                checkForWin();

                return;
            }
            else if (button[0] == button[4] && button[4] == button[8])
            {
                checkForWin();

                return;
            }
            else if (button[2] == button[4] && button[4] == button[6])
            {
                checkForWin();

                return;
            }
            else if (round == 9)
            {
                MessageBox.Show("Draw");

                gameOver = true;
                return;
            }
        }

        private void ResetScore()
        {

            CrossScore = 0;
            CircleScore = 0;
        }



        #endregion
      
    }

}   
