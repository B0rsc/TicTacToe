﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UtilitiesWpf;

namespace ZadanieKolko.Model
{
    class Field : ObserverVM
    {
        private string _mark;

        public string Mark
        {
            get { return _mark; }
            set 
            { 
                _mark = value;
                OnPropertyChanged(nameof(Mark));
            }
        }

    }
}
